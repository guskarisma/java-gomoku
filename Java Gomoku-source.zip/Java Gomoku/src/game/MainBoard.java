package game;

import javax.swing.JPanel;
import java.awt.Color;
import javax.swing.JButton;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JLabel;
import java.awt.Font;

public class MainBoard extends JPanel implements ActionListener{
	Grid board;
	JButton reset;
	JLabel title;
	JLabel description;
	
	public MainBoard(){
		setBackground(new Color(253,188,180));
		this.setLayout(null);
		board = new Grid(this);
		add(board);
		board.setBounds(20,120,200,200);
		reset = new JButton("Reset game");
		add(reset);
		reset.setBounds(240,180,150,50);
		reset.addActionListener(this);
		title=new JLabel("JAVA GOMOKU");
		title.setFont(new Font(Font.SERIF,Font.BOLD,36));
		add(title);
		title.setBounds(50,20,350,80);
		description=new JLabel("guskarisma@gmail.com");
		description.setFont(new Font(Font.MONOSPACED,Font.ITALIC,12));
		add(description);
		description.setBounds(260,340,148,50);
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource()==reset){
			board.reset();
		}
	}

}
