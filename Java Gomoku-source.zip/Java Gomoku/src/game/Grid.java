package game;

import javax.swing.JPanel;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseListener;
import java.awt.event.MouseEvent;
import java.awt.Dimension;
import javax.swing.Timer;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JOptionPane;

public class Grid extends JPanel implements MouseListener,ActionListener{		
	Component container;
	
	public Grid(Component ctr){
		this();
		container=ctr;		
	}
	
	public Grid(){
		slots=new Dot[10][10];
		setBackground(new Color(227,224,246));
		setForeground(new Color(152,153,161));
		setPreferredSize(new Dimension(200,200));
		dotCount=0;
		animator=new Timer(100,this);
		animator.start();
		addMouseListener(this);
	}//end of constructor
	
	public void paintComponent(Graphics g){
		super.paintComponent(g);
		
		//draw grid lines
		int x=20;
		int y=20;
		g.drawRect(0, 0, 199, 199);
		for(int i=1;i<10;i++){
			g.drawLine(0, i*y, 199, i*y);
			g.drawLine(i*x, 0, i*x, 199);			
		}//finish drawing grid	
		
		//paint dots
		for(int i=0;i<10;i++){
			for(int k=0;k<10;k++){
				if(slots[i][k]!=null){
					slots[i][k].paintDot(g);
				}
			}
		}//finish painting dots
	}//end of paintComponent()
	
	//resetting the board
	public void reset(){
		for (int i=0;i<10;i++){
			for(int k=0;k<10;k++){
				slots[i][k]=null;
			}
		}
		repaint();
	}
	
	//Mouse Listener Interface
	Dot[][] slots;
	int gen=0;
	Timer animator;
	int dotCount;
	public void mouseExited(MouseEvent e){};
	public void mouseClicked(MouseEvent e){};
	public void mouseEntered(MouseEvent e){};
	public void mouseReleased(MouseEvent e){};
	public void mousePressed(MouseEvent e){		
		int x=e.getX();
		int y=e.getY();
		if(x<200&&y<200){
			int col=x/20;
			int row=y/20;		
			if(slots[col][row]==null){			
				slots[col][row]=new Dot(gen,col,row,animator);
			}
			repaint();
			check(gen,col,row);
			if(gen==0){
				gen=1;
			}
			else{
				gen=0;
			}			
		}	
	}//end of Mouse Listener Interface
	
	//Action Listener Interface
	public void actionPerformed(ActionEvent e){
		repaint();
	}
	
	//checking grid for winner
	public void check(int color,int x, int y){
		int row=y;
		int col=x;
		int gen=color;
		int count=0;
		int tRow=row;
		int tCol=col;
		int mode=1;

		while(true){
			if(count==4){
				break;
			}
			if(mode>8){
				break;
			}			
			
			try{
				switch(mode){
					case 1:
						//check mode 1
						if(slots[col][row-1]!=null){							
							if(slots[col][row-1].getGen()==gen){
								count++;
								row--;								
								continue;
							}
						}
						mode++;
						row=tRow;
						break;
					case 2:
						//check mode 2
						if(slots[col][row+1]!=null){
							if(slots[col][row+1].getGen()==gen){
								count++;
								row++;
								continue;
							}
							else{
								count=0;
							}
						}
						else{
							count=0;
						}
						mode++;
						row=tRow;
						break;
					case 3:
						//check mode 3
						if(slots[col-1][row]!=null){
							if(slots[col-1][row].getGen()==gen){
								count++;
								col--;
								continue;
							}
						}
						mode++;
						col=tCol;
						break;
					case 4:
						//check mode 4
						if(slots[col+1][row]!=null){
							if(slots[col+1][row].getGen()==gen){
								count++;
								col++;
								continue;
							}
							else{
								count=0;
							}
						}
						else{
							count=0;
						}
						mode++;
						col=tCol;
						break;
					case 5:
						//check mode 5
						if(slots[col-1][row-1]!=null){
							if(slots[col-1][row-1].getGen()==gen){
								count++;
								col--;
								row--;
								continue;
							}
						}
						mode++;
						col=tCol;
						row=tRow;
						break;
					case 6:
						//check mode 6
						if(slots[col+1][row+1]!=null){
							if(slots[col+1][row+1].getGen()==gen){
								count++;
								col++;
								row++;
								continue;
							}
							else{
								count=0;
							}
						}
						else{
							count=0;
						}
						mode++;
						col=tCol;
						row=tRow;
						break;
					case 7:
						//check mode 7
						if(slots[col+1][row-1]!=null){
							if(slots[col+1][row-1].getGen()==gen){
								count++;
								col++;
								row--;
								continue;
							}
						}
						mode++;
						col=tCol;
						row=tRow;
						break;
					default:
						//check mode 8
						if(slots[col-1][row+1]!=null){
							if(slots[col-1][row+1].getGen()==gen){
								count++;
								col--;
								row++;
								continue;
							}
							else{
								count=0;
							}
						}
						else{
							count=0;
						}
						mode++;
						break;
				}
			}
			catch(ArrayIndexOutOfBoundsException ix){
				if(mode%2==0){
					count=0;
				}
				mode++;
				continue;
			}
			
			if(mode<=8){
				continue;
			}
		}
	
		if(count==4){
			congrats(gen);
		}
		
		
	}
	
	//congrats the winner
	public void congrats(int color){
		int gen=color;
		String[] player=new String[]{"Blue","Red"};
		try{
			JOptionPane.showMessageDialog(container,"Congratulations! "+player[gen]+" win!");
		}
		catch(NullPointerException x){
			JOptionPane.showMessageDialog(this,"Congratulations! "+player[gen]+" win!");
		}
	}

}
