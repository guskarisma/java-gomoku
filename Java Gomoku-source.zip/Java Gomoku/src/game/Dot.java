package game;

import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class Dot implements ActionListener{
	private final Color[] genre=new Color[]{new Color(68,114,167),new Color(255,102,102)};
	private final int x;
	private final int y;
	private final Color color;
	private boolean init;
	private int gen;
	
	public Dot(int colorType, int row, int col, Timer t){
		x=row;
		y=col;
		color=genre[colorType];
		gen=colorType;
		init=true;
		t.addActionListener(this);
	}
	
	public int getX(){
		return x;
	}
	
	public int getY(){
		return y;
	}
	
	public int getGen(){
		return gen;
	}
	
	//this block is for initial animation	
	private int frame=5;		
	public void actionPerformed(ActionEvent e){
		if(init&&frame>0){
			frame-=1;
		}
		if(frame<1){
			init=false;
		}		
	}	

	//end of initial animation
	
	public void paintDot(Graphics g){
		Graphics2D gx=(Graphics2D)g;
		gx.setRenderingHint(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
		Color prev=gx.getColor();
		gx.setColor(color);
		if(init){
			gx.fillOval(x*20+1, y*20+(frame), 19, 19);
		}
		else{
			gx.fillOval(x*20+1, y*20+1, 19, 19);
		}
		gx.setColor(prev);
	}
}
