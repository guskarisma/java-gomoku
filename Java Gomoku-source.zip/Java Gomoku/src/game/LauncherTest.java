package game;
import javax.swing.JFrame;

public class LauncherTest {
	public static void main(String[] args){
		MainBoard content=new MainBoard();
		JFrame window=new JFrame("Gomoku Game");
		window.setContentPane(content);
		window.setSize(415,400);
		window.setLocation(200,200);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}

}
